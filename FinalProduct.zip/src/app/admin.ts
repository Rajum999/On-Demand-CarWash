import { LoginComponent } from "./login/login.component";

export class Admin {
    id:number;
    username:String;
    email:String;
    password:String;
}
