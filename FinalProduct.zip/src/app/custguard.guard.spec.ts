import { TestBed } from '@angular/core/testing';

import { CustguardGuard } from './custguard.guard';

describe('CustguardGuard', () => {
  let guard: CustguardGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(CustguardGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
