import { Component, OnInit } from '@angular/core';
import { CarDetails} from './CarDetails';
import { CarbookingService } from './carbooking.service';
import { AbstractControl, FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../User';

@Component({
  selector: 'app-carbooking',
  templateUrl: './carbooking.component.html',
  styleUrls: ['./carbooking.component.css']
})
export class CarbookingComponent implements OnInit {
  public dateValue: Date = new Date();
  myStorage = window.localStorage;
  bookingForm: FormGroup;

  options = ["Saloon","Sports", "Sedan", "Hutchback", "SUV"];
  

  constructor( private apiService : CarbookingService, private route : Router) { 
    this.bookingForm = new FormGroup({
    orderId: new FormControl(null, Validators.required),
    carName : new FormControl(null, Validators.required),
    carModel: new FormControl(null, [Validators.required]),
    wName : new FormControl(null, Validators.required),
    washPackId : new FormControl(null, Validators.required),
    date : new FormControl(null, Validators.required),
    phoneNo : new FormControl(null, Validators.required),
    
    });
  }


  isFieldValid(field: string) {
    return !this.bookingForm.get(field).valid && this.bookingForm.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  carBooking(){  
    if (this.bookingForm.valid) {
      this.apiService.addCarDetails(this.bookingForm.value)
        .subscribe(
          (data) => {
           console.log(data);
            if(data){
            console.log("hello", data);
             let CarDetails = JSON.stringify(this.bookingForm.value)
             localStorage.setItem('BookingCarDetails' , CarDetails)
            this.route.navigateByUrl('/checkout')
            }
            
            else{
              alert("invalid details")
            }
          },
          error => {
            console.log(error + 'error')
           }
        );
    }
    else {
      this.validateAllFormFields(this.bookingForm);
    }
    
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      console.log(field);
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  ngOnInit(): void {
  }

  

}
