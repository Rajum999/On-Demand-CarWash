import { LoginComponent } from "./login/login.component";

export class User{
    id:number;
    username:String;
    email:String;
    password:String;

}